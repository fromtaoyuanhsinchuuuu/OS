#define MADV_NORMAL  0
#define MADV_WILLNEED 1
#define MADV_DONTNEED 2
#define MADV_PIN 3
#define MADV_UNPIN 4

